export const theme = {
    primary: "#0b0c10",
    textColor: "#66fcf1",
    titleColor: "#ffc83d"
  };